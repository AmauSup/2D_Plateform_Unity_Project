using UnityEngine;
using UnityEngine.SceneManagement;


public class GameOverManagement : MonoBehaviour
{
    public GameObject gameOverUI;

    public static GameOverManagement instance;

    public void Awake()
    {
        if (instance != null)
        {
            Debug.LogWarning("Il y a plus d'une instance GameOverManagement dans la sc�ne");
            return;
        }

        instance = this;

    }

    public void OnPlayerDeath()
    {
        
        gameOverUI.SetActive(true);
    }

    public void RetryButton()
    {
        Inventory.instance.RemoveCoins(CurrentSceneManager.instance.coinsPickedUpInThisSceneCount);
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        PlayerHealth.instance.Respawn();
        gameOverUI.SetActive(false);
    }

    public void MainMenu()
    {
        SceneManager.LoadScene("MainMenu");
    }

    public void QuitButton()
    {
        Application.Quit();
    }
}
