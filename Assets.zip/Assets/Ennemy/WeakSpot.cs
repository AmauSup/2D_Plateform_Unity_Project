using UnityEngine;

public class WeakSpot : MonoBehaviour
{
    public GameObject objectDestroyer;

    public AudioClip touchSound;


    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            AudioManager.instance.PlayClipAt(touchSound, transform.position);
            Destroy(objectDestroyer);   
        }
    }
}
